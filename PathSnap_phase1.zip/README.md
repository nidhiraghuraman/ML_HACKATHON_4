# PathSnap — GPS Map-Matching (UE24CS352A Hackathon)

PathSnap takes noisy GPS points from a vehicle and works out which road segments it actually drove on.
Pipeline: preprocessing → candidate roads per GPS point → ML model scores each candidate → HMM + Viterbi picks
the most likely connected route → FastAPI server (Laptop 1) → evaluator UI (Laptop 2).

> Status: **Phase 1 (dataset exploration) complete.** Later sections will be filled in as each phase is built.

## Project layout

```
ML_Hackathon/
├── config.yaml              all settings (paths, seeds, thresholds)
├── requirements.txt         exact package versions (Python 3.11)
├── src/pathsnap/            the reusable library code
│   ├── config.py            reads config.yaml
│   ├── io.py                loads .track / .nodes / .arcs / .route safely
│   └── geo.py               lon/lat -> metres (UTM projection per trip)
├── scripts/
│   └── explore_data.py      Phase 1: dataset report, plots, Folium maps
├── data/raw/                the dataset (NOT committed to Git)
│   ├── train/00000001/...   80 training trips
│   └── student_test/...     10 student-testing trips
└── results/exploration/     outputs of Phase 1
```

## 1. Installation (Windows, CMD, Python 3.11)

```bat
cd /d C:\Users\Nidhi\OneDrive\Desktop\ML_Hackathon
py -3.11 -m venv venv
venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Every later command assumes you are in `ML_Hackathon` with `(venv)` shown at the start of the prompt.

## 2. Dataset placement

Each trip folder must sit directly under `data\raw\train\` or `data\raw\student_test\`:

```
data\raw\train\00000001\00000001.track
data\raw\train\00000001\00000001.nodes
data\raw\train\00000001\00000001.arcs
data\raw\train\00000001\00000001.route
```

The evaluator-testing trips are not provided. On demo day they go in `data\raw\evaluator_test\<trip_id>\` on Laptop 1 only.

## 3. Phase 1 — Dataset exploration

```bat
python scripts\explore_data.py
```

Takes about 30 seconds. Writes to `results\exploration\`:

| File | Contents |
|---|---|
| `dataset_report.md` | summary of everything below, generated from the computed numbers |
| `trip_inventory.csv` | one row per trip: file sizes, row counts, timestamps, speeds, network size, connectivity, GPS-to-route distances |
| `partition_summary.json` | totals per partition + trip IDs |
| `data_quality_issues.csv` | every anomaly found (trip, issue, value) |
| `sample_rows.txt` | first rows of each file type |
| `*.png` | trip locations, trajectory lengths, sampling intervals, network size, GPS-to-road distances, data-quality counts, example trajectories |
| `maps\trip_<id>.html` | interactive Folium maps (raw GPS, road network, reference route, layer control). Opening them needs an internet connection for the map tiles |

Which Folium trips get drawn is set in `config.yaml` → `exploration.folium_trips`.

## Key dataset facts (from Phase 1)

- 80 train + 10 student-test trips, **worldwide** (34°S to 62°N), each with its **own** road network.
- GPS is nominally 1 Hz, but 14 trips have under 90% one-second steps, 23 have gaps over 60 s, and 2 have gaps over an hour.
- Road arcs are **directed**; two-way roads are stored as two arcs (median 95% of arcs have a reverse twin).
- Routes are arc-ID sequences. A route has far fewer rows than the GPS track (median ~5 GPS points per route arc), so GPS rows ≠ route rows.
- Some trips include long stationary periods (parked off-road), where GPS clusters sit 100–240 m from the route.

## Glossary

- **Node**: a point in the road network (a junction or a bend), given as lon/lat.
- **Arc**: a one-way road segment from one node to another. Its row number is its ID.
- **Candidate**: a nearby arc that a GPS point *might* belong to.
- **UTM projection**: converts lon/lat (angles) into metres on a flat grid, so distances are accurate.
